# -*- coding: utf-8 -*-
import sys, json, urllib.parse, urllib.request, traceback
import xbmc, xbmcaddon, xbmcgui, xbmcplugin

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])
BASE = sys.argv[0]
FANART = ADDON.getAddonInfo('path') + '/resources/media/fanart.jpg'
ICON = ADDON.getAddonInfo('path') + '/resources/media/icon.png'
UA = 'Mozilla/5.0 (StreamChamps Kodi Addon)'

LEAGUES = {
    'nfl': {'label':'NFL', 'sport':'football', 'league':'nfl', 'news':'https://site.api.espn.com/apis/site/v2/sports/football/nfl/news', 'scoreboard':'https://site.api.espn.com/apis/site/v2/sports/football/nfl/scoreboard', 'stats':'https://www.espn.com/nfl/stats', 'standings':'https://www.espn.com/nfl/standings', 'video_q':'NFL news highlights'},
    'nba': {'label':'NBA', 'sport':'basketball', 'league':'nba', 'news':'https://site.api.espn.com/apis/site/v2/sports/basketball/nba/news', 'scoreboard':'https://site.api.espn.com/apis/site/v2/sports/basketball/nba/scoreboard', 'stats':'https://www.espn.com/nba/stats', 'standings':'https://www.espn.com/nba/standings', 'video_q':'NBA news highlights'},
    'nhl': {'label':'NHL', 'sport':'hockey', 'league':'nhl', 'news':'https://site.api.espn.com/apis/site/v2/sports/hockey/nhl/news', 'scoreboard':'https://site.api.espn.com/apis/site/v2/sports/hockey/nhl/scoreboard', 'stats':'https://www.espn.com/nhl/stats', 'standings':'https://www.espn.com/nhl/standings', 'video_q':'NHL news highlights'},
    'soccer': {'label':'Soccer', 'sport':'soccer', 'league':'eng.1', 'news':'https://site.api.espn.com/apis/site/v2/sports/soccer/eng.1/news', 'scoreboard':'https://site.api.espn.com/apis/site/v2/sports/soccer/eng.1/scoreboard', 'stats':'https://www.espn.com/soccer/stats/_/league/eng.1', 'standings':'https://www.espn.com/soccer/standings/_/league/eng.1', 'video_q':'soccer news highlights'},
}

def build_url(query):
    return BASE + '?' + urllib.parse.urlencode(query)

def fetch_json(url):
    req = urllib.request.Request(url, headers={'User-Agent': UA})
    with urllib.request.urlopen(req, timeout=12) as r:
        return json.loads(r.read().decode('utf-8', errors='ignore'))

def add_item(label, mode=None, league=None, url=None, plot='', art=None, folder=True):
    li = xbmcgui.ListItem(label=label)
    li.setArt({'thumb': art or ICON, 'icon': art or ICON, 'fanart': FANART})
    li.setInfo('video', {'title': label, 'plot': plot})
    if mode:
        path = build_url({'mode': mode, 'league': league or ''})
    else:
        path = url or ''
    xbmcplugin.addDirectoryItem(HANDLE, path, li, folder)

def end():
    xbmcplugin.setContent(HANDLE, 'videos')
    xbmcplugin.endOfDirectory(HANDLE)

def home():
    add_item('🏈 NFL Sports Hub', 'league', 'nfl', plot='NFL news, schedules, standings, stats and video news.')
    add_item('🏀 NBA Sports Hub', 'league', 'nba', plot='NBA news, schedules, standings, stats and video news.')
    add_item('🏒 NHL Sports Hub', 'league', 'nhl', plot='NHL news, schedules, standings, stats and video news.')
    add_item('⚽ Soccer Sports Hub', 'league', 'soccer', plot='Soccer news, schedules, standings, stats and video news.')
    add_item('⭐ About StreamChamps Sports Hub', 'about', plot='Powered by StreamChamps.')
    end()

def league_menu(key):
    l = LEAGUES[key]
    add_item('📰 Latest %s News' % l['label'], 'news', key, plot='Auto-refreshing public headlines.')
    add_item('🎥 %s Video News' % l['label'], 'videos', key, plot='Opens YouTube news/highlight searches if the YouTube add-on is installed.')
    add_item('📅 %s Scores & Schedule' % l['label'], 'schedule', key, plot='Public ESPN scoreboard/schedule feed.')
    add_item('📊 %s Player Stats' % l['label'], 'stats', key, plot='Player stats link/source page.')
    add_item('🏆 %s Standings' % l['label'], 'standings', key, plot='League standings link/source page.')
    end()

def news(key):
    l = LEAGUES[key]
    try:
        data = fetch_json(l['news'])
        articles = data.get('articles', [])[:40]
        if not articles:
            add_item('No news found right now. Try again later.', plot='The feed returned no articles.', folder=False)
        for a in articles:
            title = a.get('headline') or a.get('title') or 'Untitled article'
            desc = a.get('description') or a.get('story') or ''
            link = (a.get('links') or {}).get('web', {}).get('href') or a.get('link') or ''
            img = ICON
            images = a.get('images') or []
            if images:
                img = images[0].get('url') or ICON
            add_item(title, plot=(desc + '\n\nSource link:\n' + link), art=img, folder=False)
    except Exception as e:
        add_item('News feed error', plot=str(e), folder=False)
    end()

def schedule(key):
    l = LEAGUES[key]
    try:
        data = fetch_json(l['scoreboard'])
        events = data.get('events', [])[:60]
        if not events:
            add_item('No games found right now.', plot='No games returned from schedule feed.', folder=False)
        for ev in events:
            name = ev.get('shortName') or ev.get('name') or 'Game'
            comp = (ev.get('competitions') or [{}])[0]
            status = (comp.get('status') or {}).get('type', {}).get('description') or ''
            detail = (comp.get('status') or {}).get('type', {}).get('shortDetail') or ''
            comps = comp.get('competitors') or []
            scoreline = []
            for c in comps:
                team = (c.get('team') or {}).get('abbreviation') or (c.get('team') or {}).get('shortDisplayName') or ''
                score = c.get('score') or ''
                if team:
                    scoreline.append('%s %s' % (team, score))
            plot = 'Status: %s\n%s\n\n%s' % (status, detail, ' | '.join(scoreline))
            add_item('%s — %s' % (name, status), plot=plot, folder=False)
    except Exception as e:
        add_item('Schedule feed error', plot=str(e), folder=False)
    end()

def videos(key):
    q = LEAGUES[key]['video_q']
    add_item('Open %s on YouTube' % q, url='plugin://plugin.video.youtube/search/?q=' + urllib.parse.quote_plus(q), plot='Requires Kodi YouTube add-on.', folder=True)
    add_item('Open StreamChamps sports news search', url='plugin://plugin.video.youtube/search/?q=' + urllib.parse.quote_plus('StreamChamps ' + q), plot='Requires Kodi YouTube add-on.', folder=True)
    end()

def link_page(key, kind):
    l = LEAGUES[key]
    url = l[kind]
    label = ('Player Stats' if kind == 'stats' else 'Standings')
    add_item('%s %s Source Link' % (l['label'], label), plot='Kodi cannot display every web table cleanly here yet. Source link:\n%s' % url, folder=False)
    end()

def about():
    add_item('StreamChamps Sports Hub v2.0.0', plot='NFL, NBA, NHL and Soccer hub with news, video news search, schedules, standings links and player stats links. Built for Kodi 21 Omega. Powered by StreamChamps.', folder=False)
    end()

def router():
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    mode = params.get('mode')
    league = params.get('league')
    if not mode: return home()
    if mode == 'league': return league_menu(league)
    if mode == 'news': return news(league)
    if mode == 'schedule': return schedule(league)
    if mode == 'videos': return videos(league)
    if mode == 'stats': return link_page(league, 'stats')
    if mode == 'standings': return link_page(league, 'standings')
    if mode == 'about': return about()
    home()

try:
    router()
except Exception:
    xbmcgui.Dialog().notification('StreamChamps Error', 'Check Kodi log for details.', xbmcgui.NOTIFICATION_ERROR, 5000)
    xbmc.log(traceback.format_exc(), xbmc.LOGERROR)
