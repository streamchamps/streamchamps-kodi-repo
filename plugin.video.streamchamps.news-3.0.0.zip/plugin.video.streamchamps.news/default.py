# -*- coding: utf-8 -*-
import sys, json, urllib.parse, urllib.request, traceback, re
import xbmc, xbmcaddon, xbmcgui, xbmcplugin

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])
BASE = sys.argv[0]
PATH = ADDON.getAddonInfo('path')
FANART = PATH + '/resources/media/fanart.jpg'
ICON = PATH + '/resources/media/icon.png'
UA = 'Mozilla/5.0 (StreamChamps Sports Hub Kodi Addon)'

LEAGUES = {
    'nfl': {'label':'NFL', 'sport':'football', 'league':'nfl', 'news':'https://site.api.espn.com/apis/site/v2/sports/football/nfl/news', 'scoreboard':'https://site.api.espn.com/apis/site/v2/sports/football/nfl/scoreboard', 'stats':'https://www.espn.com/nfl/stats', 'standings':'https://www.espn.com/nfl/standings', 'video_q':'NFL news highlights', 'teams': {'Washington Commanders':'wsh','Dallas Cowboys':'dal','Philadelphia Eagles':'phi','New York Giants':'nyg'}},
    'nba': {'label':'NBA', 'sport':'basketball', 'league':'nba', 'news':'https://site.api.espn.com/apis/site/v2/sports/basketball/nba/news', 'scoreboard':'https://site.api.espn.com/apis/site/v2/sports/basketball/nba/scoreboard', 'stats':'https://www.espn.com/nba/stats', 'standings':'https://www.espn.com/nba/standings', 'video_q':'NBA news highlights', 'teams': {'New York Knicks':'ny','Boston Celtics':'bos','Los Angeles Lakers':'lal','Golden State Warriors':'gs'}},
    'nhl': {'label':'NHL', 'sport':'hockey', 'league':'nhl', 'news':'https://site.api.espn.com/apis/site/v2/sports/hockey/nhl/news', 'scoreboard':'https://site.api.espn.com/apis/site/v2/sports/hockey/nhl/scoreboard', 'stats':'https://www.espn.com/nhl/stats', 'standings':'https://www.espn.com/nhl/standings', 'video_q':'NHL news highlights', 'teams': {'Washington Capitals':'wsh','New York Rangers':'nyr','Carolina Hurricanes':'car','Toronto Maple Leafs':'tor'}},
    'soccer': {'label':'Soccer', 'sport':'soccer', 'league':'eng.1', 'news':'https://site.api.espn.com/apis/site/v2/sports/soccer/eng.1/news', 'scoreboard':'https://site.api.espn.com/apis/site/v2/sports/soccer/eng.1/scoreboard', 'stats':'https://www.espn.com/soccer/stats/_/league/eng.1', 'standings':'https://www.espn.com/soccer/standings/_/league/eng.1', 'video_q':'soccer news highlights', 'teams': {'Premier League':'eng.1','MLS':'usa.1','Champions League':'uefa.champions','LaLiga':'esp.1'}},
}

TEAM_NEWS_URLS = {
    ('nfl','wsh'):'https://site.api.espn.com/apis/site/v2/sports/football/nfl/teams/wsh/news',
    ('nba','ny'):'https://site.api.espn.com/apis/site/v2/sports/basketball/nba/teams/ny/news',
    ('nhl','wsh'):'https://site.api.espn.com/apis/site/v2/sports/hockey/nhl/teams/wsh/news',
}

def clean_html(text):
    if not text: return ''
    text = re.sub(r'<br\s*/?>', '\n', text)
    text = re.sub(r'<[^>]+>', '', text)
    repl = {'&amp;':'&','&quot;':'"','&#39;':"'",'&nbsp;':' '}
    for k,v in repl.items(): text = text.replace(k,v)
    return text.strip()

def build_url(query): return BASE + '?' + urllib.parse.urlencode(query)

def fetch_json(url):
    req = urllib.request.Request(url, headers={'User-Agent': UA})
    with urllib.request.urlopen(req, timeout=14) as r:
        return json.loads(r.read().decode('utf-8', errors='ignore'))

def item(label, mode=None, league=None, plot='', art=None, folder=True, extra=None, url=None):
    li = xbmcgui.ListItem(label=label)
    li.setArt({'thumb': art or ICON, 'icon': art or ICON, 'fanart': FANART})
    li.setInfo('video', {'title': label, 'plot': plot})
    li.setProperty('IsPlayable', 'false')
    if mode:
        q={'mode': mode}
        if league: q['league']=league
        if extra: q.update(extra)
        path=build_url(q)
    else:
        path=url or ''
    xbmcplugin.addDirectoryItem(HANDLE, path, li, folder)

def end():
    xbmcplugin.setContent(HANDLE, 'videos')
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL)
    xbmcplugin.endOfDirectory(HANDLE)

def home():
    item('⚡ StreamChamps Sports Hub', 'about', plot='NFL, NBA, NHL, Soccer, video news, schedules, standings and player stats. Powered by StreamChamps.')
    item('🔥 Breaking Sports News', 'breaking', plot='Latest public feed stories across NFL, NBA, NHL and Soccer.')
    item('🏈 NFL', 'league', 'nfl')
    item('🏀 NBA', 'league', 'nba')
    item('🏒 NHL', 'league', 'nhl')
    item('⚽ Soccer', 'league', 'soccer')
    item('🎥 Video News', 'allvideos', plot='Video search links for every sport.')
    end()

def league_menu(key):
    l=LEAGUES[key]
    item('📰 Latest %s Stories' % l['label'], 'news', key, plot='Click a story to read the public feed summary inside Kodi.')
    item('⭐ Team / League Hubs', 'teams', key, plot='Team-specific menus and source links.')
    item('📅 Scores & Schedule', 'schedule', key, plot='Live/finished/upcoming games from public ESPN scoreboard feed when available.')
    item('🏆 Standings', 'standings', key, plot=l['standings'])
    item('📊 Player Stats', 'stats', key, plot=l['stats'])
    item('🎥 Video News', 'videos', key, plot='YouTube search links. Requires Kodi YouTube add-on.')
    end()

def article_payload(a, league_label):
    title=a.get('headline') or a.get('title') or 'Untitled story'
    desc=clean_html(a.get('description') or '')
    story=clean_html(a.get('story') or '')
    link=(a.get('links') or {}).get('web',{}).get('href') or a.get('link') or ''
    byline=a.get('byline') or ''
    published=a.get('published') or a.get('lastModified') or ''
    images=a.get('images') or []
    img=images[0].get('url') if images else ICON
    parts=[]
    if byline: parts.append('By: '+byline)
    if published: parts.append('Published: '+published)
    if desc: parts.append(desc)
    if story and story != desc: parts.append(story)
    if not desc and not story: parts.append('This public feed did not include a full summary. Use the source link for the full article.')
    if link: parts.append('Source / full article:\n'+link)
    parts.append('\nPowered by StreamChamps Sports Hub')
    return {'title': title, 'body':'\n\n'.join(parts), 'img':img, 'league':league_label, 'link':link}

def list_news(key, url=None, label_prefix=''):
    l=LEAGUES[key]
    try:
        data=fetch_json(url or l['news'])
        arts=data.get('articles', [])[:50]
        if not arts: item('No stories found right now.', plot='Try again later.', folder=False)
        for a in arts:
            p=article_payload(a,l['label'])
            item(label_prefix+p['title'], 'article', key, plot=p['body'][:4000], art=p['img'], extra={'data':json.dumps(p)})
    except Exception as e:
        item('News feed error', plot=str(e), folder=False)
    end()

def breaking():
    for key in ['nfl','nba','nhl','soccer']:
        try:
            data=fetch_json(LEAGUES[key]['news'])
            for a in data.get('articles', [])[:10]:
                p=article_payload(a,LEAGUES[key]['label'])
                item('[%s] %s'%(LEAGUES[key]['label'],p['title']), 'article', key, plot=p['body'][:4000], art=p['img'], extra={'data':json.dumps(p)})
        except Exception: pass
    end()

def article():
    params=dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    p=json.loads(params.get('data','{}'))
    title=p.get('title','Story'); body=p.get('body','')
    xbmcgui.Dialog().textviewer('StreamChamps Story', title+'\n\n'+body)
    item('📖 '+title, plot=body, art=p.get('img') or ICON, folder=False)
    if p.get('link'): item('🌐 Source / Full Article', plot=p.get('link'), art=p.get('img') or ICON, folder=False)
    end()

def schedule(key):
    l=LEAGUES[key]
    try:
        data=fetch_json(l['scoreboard'])
        events=data.get('events', [])[:75]
        if not events: item('No games found right now.', plot='No games returned by the schedule feed.', folder=False)
        for ev in events:
            comp=(ev.get('competitions') or [{}])[0]
            status=(comp.get('status') or {}).get('type',{}).get('description') or ''
            detail=(comp.get('status') or {}).get('type',{}).get('shortDetail') or ev.get('date','')
            name=ev.get('shortName') or ev.get('name') or 'Game'
            scoreline=[]
            for c in comp.get('competitors') or []:
                tm=(c.get('team') or {}).get('abbreviation') or (c.get('team') or {}).get('shortDisplayName') or ''
                sc=c.get('score') or ''
                if tm: scoreline.append((tm+' '+str(sc)).strip())
            plot='Status: %s\n%s\n\n%s'%(status,detail,' | '.join(scoreline))
            item('%s — %s'%(name,status), plot=plot, folder=False)
    except Exception as e:
        item('Schedule feed error', plot=str(e), folder=False)
    end()

def teams(key):
    l=LEAGUES[key]
    for name, code in l.get('teams', {}).items():
        item('⭐ '+name, 'team', key, plot='Team/league hub for '+name, extra={'team':code,'team_name':name})
    end()

def team(key, code, name):
    item('📰 '+name+' News', 'teamnews', key, extra={'team':code,'team_name':name})
    item('📅 '+name+' Schedule Source', plot='Team schedule/source page. Open league schedule for feed-based games.', folder=False)
    item('📊 '+name+' Stats Source', plot='Team/player stats source is linked from the league stats page.', folder=False)
    item('🎥 '+name+' Video News', url='plugin://plugin.video.youtube/search/?q='+urllib.parse.quote_plus(name+' news highlights'), folder=True)
    end()

def teamnews(key, code, name):
    url=TEAM_NEWS_URLS.get((key,code))
    if url: return list_news(key, url, '')
    # fallback: league news with label only
    return list_news(key, None, '['+name+'] ')

def videos(key):
    q=LEAGUES[key]['video_q']
    item('YouTube: '+q, url='plugin://plugin.video.youtube/search/?q='+urllib.parse.quote_plus(q), folder=True)
    item('YouTube: StreamChamps '+q, url='plugin://plugin.video.youtube/search/?q='+urllib.parse.quote_plus('StreamChamps '+q), folder=True)
    end()

def allvideos():
    for key in ['nfl','nba','nhl','soccer']:
        item('🎥 '+LEAGUES[key]['label']+' Video News', 'videos', key)
    end()

def source_link(key, kind):
    l=LEAGUES[key]
    url=l[kind]
    title=l['label']+' '+('Player Stats' if kind=='stats' else 'Standings')
    item(title, plot='Source link:\n'+url+'\n\nFuture upgrade: display these tables directly in Kodi using a sports data API key.', folder=False)
    end()

def about():
    item('⚡ StreamChamps Sports Hub v3.0.0', plot='Powered by StreamChamps. NFL, NBA, NHL and Soccer. News story pages, video news, schedules, standings links and player stats links. No live streams. Built for Kodi 21 Omega.', folder=False)
    end()

def router():
    params=dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    mode=params.get('mode'); league=params.get('league'); team_code=params.get('team'); team_name=params.get('team_name','Team')
    if not mode: return home()
    if mode=='league': return league_menu(league)
    if mode=='news': return list_news(league)
    if mode=='breaking': return breaking()
    if mode=='article': return article()
    if mode=='schedule': return schedule(league)
    if mode=='teams': return teams(league)
    if mode=='team': return team(league, team_code, team_name)
    if mode=='teamnews': return teamnews(league, team_code, team_name)
    if mode=='videos': return videos(league)
    if mode=='allvideos': return allvideos()
    if mode=='stats': return source_link(league,'stats')
    if mode=='standings': return source_link(league,'standings')
    if mode=='about': return about()
    return home()
try:
    router()
except Exception:
    xbmcgui.Dialog().notification('StreamChamps Error', 'Check Kodi log for details.', xbmcgui.NOTIFICATION_ERROR, 5000)
    xbmc.log(traceback.format_exc(), xbmc.LOGERROR)
