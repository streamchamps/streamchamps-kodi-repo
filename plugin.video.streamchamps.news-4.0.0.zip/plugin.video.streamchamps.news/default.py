# -*- coding: utf-8 -*-
import sys, json, urllib.parse, urllib.request, traceback, re
import xbmc, xbmcaddon, xbmcgui, xbmcplugin
ADDON=xbmcaddon.Addon(); HANDLE=int(sys.argv[1]); BASE=sys.argv[0]
PATH=ADDON.getAddonInfo('path'); FANART=PATH+'/resources/media/fanart.jpg'; ICON=PATH+'/resources/media/icon.png'
UA='Mozilla/5.0 (StreamChamps Sports Hub Kodi Addon)'
LEAGUES={
 'nfl': {'label':'NFL','news':'https://site.api.espn.com/apis/site/v2/sports/football/nfl/news','scoreboard':'https://site.api.espn.com/apis/site/v2/sports/football/nfl/scoreboard','standings':'https://www.espn.com/nfl/standings','stats':'https://www.espn.com/nfl/stats','video_q':'NFL news highlights'},
 'nba': {'label':'NBA','news':'https://site.api.espn.com/apis/site/v2/sports/basketball/nba/news','scoreboard':'https://site.api.espn.com/apis/site/v2/sports/basketball/nba/scoreboard','standings':'https://www.espn.com/nba/standings','stats':'https://www.espn.com/nba/stats','video_q':'NBA news highlights'},
 'nhl': {'label':'NHL','news':'https://site.api.espn.com/apis/site/v2/sports/hockey/nhl/news','scoreboard':'https://site.api.espn.com/apis/site/v2/sports/hockey/nhl/scoreboard','standings':'https://www.espn.com/nhl/standings','stats':'https://www.espn.com/nhl/stats','video_q':'NHL news highlights'},
}
SOCCER={
 'World Cup':'fifa.world','Premier League':'eng.1','UEFA Champions League':'uefa.champions','MLS':'usa.1','La Liga':'esp.1','Bundesliga':'ger.1','Serie A':'ita.1','Ligue 1':'fra.1','Liga MX':'mex.1','Saudi Pro League':'ksa.1','Eredivisie':'ned.1','Scottish Premiership':'sco.1','English Championship':'eng.2','NWSL':'usa.nwsl','UEFA Europa League':'uefa.europa','Copa America':'conmebol.america','Euro Championship':'uefa.euro'
}
def clean(t):
 if not t: return ''
 t=re.sub(r'<br\s*/?>','\n',t); t=re.sub(r'<[^>]+>','',t)
 for k,v in {'&amp;':'&','&quot;':'"','&#39;':"'",'&nbsp;':' '}.items(): t=t.replace(k,v)
 return t.strip()
def url(q): return BASE+'?'+urllib.parse.urlencode(q)
def fetch(u):
 req=urllib.request.Request(u,headers={'User-Agent':UA})
 with urllib.request.urlopen(req,timeout=14) as r: return json.loads(r.read().decode('utf-8','ignore'))
def add(label,mode=None,league=None,plot='',art=None,folder=True,extra=None,path=None):
 li=xbmcgui.ListItem(label=label); li.setArt({'thumb':art or ICON,'icon':art or ICON,'fanart':FANART}); li.setInfo('video',{'title':label,'plot':plot}); li.setProperty('IsPlayable','false')
 p=path or ''
 if mode:
  q={'mode':mode};
  if league: q['league']=league
  if extra: q.update(extra)
  p=url(q)
 xbmcplugin.addDirectoryItem(HANDLE,p,li,folder)
def end(): xbmcplugin.setContent(HANDLE,'videos'); xbmcplugin.endOfDirectory(HANDLE)
def home():
 add('⚡ STREAMCHAMPS SPORTS HUB','about',plot='League-wide hub: NFL, NBA, NHL, Soccer, news, schedules, standings, stats and video news.')
 add('🔥 Breaking Sports News','breaking')
 add('🏈 NFL','league','nfl'); add('🏀 NBA','league','nba'); add('🏒 NHL','league','nhl'); add('⚽ Soccer Leagues','soccer_home')
 add('🎥 Video News Hub','allvideos'); add('📊 Standings Hub','standings_hub'); add('📅 Schedules Hub','schedules_hub'); add('👤 Player Stats Hub','stats_hub')
 end()
def league_menu(k):
 l=LEAGUES[k]
 add('📰 Latest '+l['label']+' Stories','news',k,plot='Open a story to read the public summary inside Kodi.')
 add('📅 Scores & Schedule','schedule',k); add('🏆 Standings','source',k,extra={'kind':'standings'}); add('👤 Player Stats','source',k,extra={'kind':'stats'}); add('🎥 Video News','videos',k)
 end()
def soccer_home():
 add('📰 Soccer News','soccer_news',extra={'code':'eng.1','name':'Soccer'})
 add('🌎 World Cup','soccer_league',extra={'code':'fifa.world','name':'World Cup'})
 for name,code in SOCCER.items():
  if name!='World Cup': add('⚽ '+name,'soccer_league',extra={'code':code,'name':name})
 end()
def soccer_league(code,name):
 add('📰 '+name+' News','soccer_news',extra={'code':code,'name':name}); add('📅 '+name+' Scores & Fixtures','soccer_schedule',extra={'code':code,'name':name})
 add('🏆 '+name+' Table / Standings',plot='https://www.espn.com/soccer/standings/_/league/'+code,folder=False)
 add('👤 '+name+' Stats / Leaders',plot='https://www.espn.com/soccer/stats/_/league/'+code,folder=False)
 add('🎥 '+name+' Video News',path='plugin://plugin.video.youtube/search/?q='+urllib.parse.quote_plus(name+' soccer highlights news'),folder=True)
 end()
def article_payload(a,label):
 title=a.get('headline') or a.get('title') or 'Untitled story'; desc=clean(a.get('description') or ''); story=clean(a.get('story') or '')
 link=(a.get('links') or {}).get('web',{}).get('href') or a.get('link') or ''; imgs=a.get('images') or []; img=imgs[0].get('url') if imgs else ICON
 parts=[]
 if a.get('byline'): parts.append('By: '+a.get('byline'))
 if a.get('published'): parts.append('Published: '+a.get('published'))
 if desc: parts.append(desc)
 if story and story!=desc: parts.append(story)
 if not desc and not story: parts.append('This public feed did not include the full article body. Use the source link for the full story.')
 if link: parts.append('Source / full article:\n'+link)
 parts.append('\nPowered by StreamChamps Sports Hub')
 return {'title':title,'body':'\n\n'.join(parts),'img':img,'link':link}
def list_news(k,u=None,prefix=''):
 try:
  data=fetch(u or LEAGUES[k]['news']); arts=data.get('articles',[])[:50]
  if not arts: add('No stories found right now.',folder=False)
  for a in arts:
   p=article_payload(a,LEAGUES[k]['label']); add(prefix+p['title'],'article',k,plot=p['body'][:4000],art=p['img'],extra={'data':json.dumps(p)})
 except Exception as e: add('News feed error',plot=str(e),folder=False)
 end()
def soccer_news(code,name): list_news('nfl','https://site.api.espn.com/apis/site/v2/sports/soccer/%s/news'%code,'[%s] '%name)
def breaking():
 for k in ['nfl','nba','nhl']:
  try:
   data=fetch(LEAGUES[k]['news'])
   for a in data.get('articles',[])[:8]:
    p=article_payload(a,LEAGUES[k]['label']); add('[%s] %s'%(LEAGUES[k]['label'],p['title']),'article',k,plot=p['body'][:4000],art=p['img'],extra={'data':json.dumps(p)})
  except Exception: pass
 try:
  data=fetch('https://site.api.espn.com/apis/site/v2/sports/soccer/eng.1/news')
  for a in data.get('articles',[])[:8]:
   p=article_payload(a,'Soccer'); add('[Soccer] '+p['title'],'article','nfl',plot=p['body'][:4000],art=p['img'],extra={'data':json.dumps(p)})
 except Exception: pass
 end()
def article():
 p=json.loads(dict(urllib.parse.parse_qsl(sys.argv[2][1:])).get('data','{}')); xbmcgui.Dialog().textviewer('StreamChamps Story',p.get('title','Story')+'\n\n'+p.get('body',''))
 add('📖 '+p.get('title','Story'),plot=p.get('body',''),art=p.get('img') or ICON,folder=False); end()
def show_schedule(label,u):
 try:
  data=fetch(u); evs=data.get('events',[])[:80]
  if not evs: add('No games found right now.',folder=False)
  for ev in evs:
   comp=(ev.get('competitions') or [{}])[0]; st=(comp.get('status') or {}).get('type',{}).get('description') or ''; detail=(comp.get('status') or {}).get('type',{}).get('shortDetail') or ev.get('date','')
   name=ev.get('shortName') or ev.get('name') or label+' Game'; scores=[]
   for c in comp.get('competitors') or []:
    tm=(c.get('team') or {}).get('abbreviation') or (c.get('team') or {}).get('shortDisplayName') or ''; sc=c.get('score') or ''
    if tm: scores.append((tm+' '+str(sc)).strip())
   add(name+' — '+st,plot='Status: '+st+'\n'+detail+'\n\n'+' | '.join(scores),folder=False)
 except Exception as e: add('Schedule feed error',plot=str(e),folder=False)
 end()
def schedule(k): show_schedule(LEAGUES[k]['label'],LEAGUES[k]['scoreboard'])
def soccer_schedule(code,name): show_schedule(name,'https://site.api.espn.com/apis/site/v2/sports/soccer/%s/scoreboard'%code)
def source(k,kind): add(LEAGUES[k]['label']+' '+kind.title(),plot=LEAGUES[k][kind],folder=False); end()
def videos(k): add('YouTube: '+LEAGUES[k]['video_q'],path='plugin://plugin.video.youtube/search/?q='+urllib.parse.quote_plus(LEAGUES[k]['video_q']),folder=True); end()
def allvideos():
 for k in ['nfl','nba','nhl']: add('🎥 '+LEAGUES[k]['label']+' Video News','videos',k)
 for n,c in list(SOCCER.items())[:8]: add('🎥 '+n+' Videos',path='plugin://plugin.video.youtube/search/?q='+urllib.parse.quote_plus(n+' highlights news'),folder=True)
 end()
def standings_hub():
 for k in ['nfl','nba','nhl']: add('🏆 '+LEAGUES[k]['label']+' Standings','source',k,extra={'kind':'standings'})
 add('🏆 Soccer Tables','soccer_home'); end()
def schedules_hub():
 for k in ['nfl','nba','nhl']: add('📅 '+LEAGUES[k]['label']+' Schedule','schedule',k)
 add('📅 Soccer Fixtures','soccer_home'); end()
def stats_hub():
 for k in ['nfl','nba','nhl']: add('👤 '+LEAGUES[k]['label']+' Player Stats','source',k,extra={'kind':'stats'})
 add('👤 Soccer Player Stats','soccer_home'); end()
def about(): add('⚡ StreamChamps Sports Hub v4.0.0',plot='League-wide build with NFL, NBA, NHL, Soccer including World Cup and multiple soccer leagues. Public news summaries, schedules, standings links, player stats links and video news searches. No unauthorized streams.',folder=False); end()
def router():
 p=dict(urllib.parse.parse_qsl(sys.argv[2][1:])); m=p.get('mode'); l=p.get('league')
 if not m: return home()
 if m=='league': return league_menu(l)
 if m=='news': return list_news(l)
 if m=='breaking': return breaking()
 if m=='article': return article()
 if m=='schedule': return schedule(l)
 if m=='source': return source(l,p.get('kind'))
 if m=='videos': return videos(l)
 if m=='allvideos': return allvideos()
 if m=='soccer_home': return soccer_home()
 if m=='soccer_league': return soccer_league(p.get('code'),p.get('name'))
 if m=='soccer_news': return soccer_news(p.get('code'),p.get('name'))
 if m=='soccer_schedule': return soccer_schedule(p.get('code'),p.get('name'))
 if m=='standings_hub': return standings_hub()
 if m=='schedules_hub': return schedules_hub()
 if m=='stats_hub': return stats_hub()
 if m=='about': return about()
 return home()
try: router()
except Exception:
 xbmcgui.Dialog().notification('StreamChamps Error','Check Kodi log for details.',xbmcgui.NOTIFICATION_ERROR,5000); xbmc.log(traceback.format_exc(),xbmc.LOGERROR)
