StreamChamps News Hub for Kodi 21 Omega

Install directly:
1. Kodi > Settings > System > Add-ons > Unknown sources ON.
2. Add-ons > Install from zip file.
3. Select plugin.video.streamchamps.news-1.0.0.zip.
4. Open Add-ons > Video add-ons > StreamChamps News Hub.

Repository URL for fans after GitHub Pages is enabled:
https://streamchamps.github.io/streamchamps-kodi-repo/
