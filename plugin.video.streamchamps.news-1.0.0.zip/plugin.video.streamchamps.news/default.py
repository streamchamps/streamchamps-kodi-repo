# -*- coding: utf-8 -*-
from __future__ import unicode_literals

import html
import json
import sys
import urllib.parse
import urllib.request

import xbmcaddon
import xbmcgui
import xbmcplugin

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]
ADDON_PATH = ADDON.getAddonInfo('path')
ICON = ADDON_PATH + '/resources/media/icon.png'
FANART = ADDON_PATH + '/resources/media/fanart.jpg'
USER_AGENT = 'Mozilla/5.0 (StreamChamps News Hub for Kodi)'

FEEDS = {
    'nfl': 'https://site.api.espn.com/apis/site/v2/sports/football/nfl/news?limit=40',
    'nba': 'https://site.api.espn.com/apis/site/v2/sports/basketball/nba/news?limit=40',
}


def build_url(query):
    return BASE_URL + '?' + urllib.parse.urlencode(query)


def fetch_json(url):
    req = urllib.request.Request(url, headers={'User-Agent': USER_AGENT})
    with urllib.request.urlopen(req, timeout=20) as response:
        return json.loads(response.read().decode('utf-8', errors='ignore'))


def add_dir(label, action, params=None, plot=''):
    query = {'action': action}
    if params:
        query.update(params)
    li = xbmcgui.ListItem(label=label)
    li.setArt({'icon': ICON, 'thumb': ICON, 'fanart': FANART})
    li.setInfo('video', {'title': label, 'plot': plot})
    xbmcplugin.addDirectoryItem(HANDLE, build_url(query), li, True)


def add_article(title, summary, url='', image=None, source=''):
    title = html.unescape(title or 'Untitled')
    summary = html.unescape(summary or 'No summary available.')
    if url:
        summary = summary + '\n\nSource link:\n' + url
    if source:
        summary = source + '\n\n' + summary
    li = xbmcgui.ListItem(label=title)
    li.setArt({'icon': image or ICON, 'thumb': image or ICON, 'fanart': FANART})
    li.setInfo('video', {'title': title, 'plot': summary})
    xbmcplugin.addDirectoryItem(HANDLE, build_url({'action': 'read', 'title': title, 'summary': summary}), li, False)


def root():
    add_dir('[B]🏈 NFL News[/B]', 'news', {'league': 'nfl'}, 'Latest NFL headlines powered by StreamChamps.')
    add_dir('[B]🏀 NBA News[/B]', 'news', {'league': 'nba'}, 'Latest NBA headlines powered by StreamChamps.')
    add_dir('ℹ️ About StreamChamps News Hub', 'about')
    xbmcplugin.setContent(HANDLE, 'videos')
    xbmcplugin.endOfDirectory(HANDLE)


def news(league):
    try:
        data = fetch_json(FEEDS[league])
        for article in data.get('articles', []):
            links = article.get('links') or {}
            web_url = ''
            if isinstance(links.get('web'), dict):
                web_url = links.get('web', {}).get('href', '')
            images = article.get('images') or []
            image = images[0].get('url') if images and isinstance(images[0], dict) else ICON
            source = article.get('source') or article.get('byline') or 'ESPN'
            add_article(article.get('headline'), article.get('description') or article.get('story'), web_url, image, source)
    except Exception as exc:
        xbmcgui.Dialog().notification('StreamChamps', 'Could not load news: {}'.format(exc), ICON, 7000)
    xbmcplugin.setContent(HANDLE, 'videos')
    xbmcplugin.endOfDirectory(HANDLE)


def read_article(title, summary):
    xbmcgui.Dialog().textviewer(title, summary)
    xbmcplugin.endOfDirectory(HANDLE, succeeded=False)


def about():
    xbmcgui.Dialog().textviewer('StreamChamps News Hub', 'StreamChamps News Hub\n\nNFL and NBA headlines for Kodi 21 Omega.\n\nThis add-on uses public ESPN news data and does not provide live streams or copyrighted game broadcasts.\n\nPowered by StreamChamps.')
    xbmcplugin.endOfDirectory(HANDLE, succeeded=False)


params = dict(urllib.parse.parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
action = params.get('action', '')

if action == 'news':
    news(params.get('league', 'nfl'))
elif action == 'read':
    read_article(params.get('title', 'Article'), params.get('summary', ''))
elif action == 'about':
    about()
else:
    root()
